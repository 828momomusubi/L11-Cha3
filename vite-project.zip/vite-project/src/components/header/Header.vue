<script setup>
import { signOut, getAuth } from "firebase/auth";
import { useRouter } from "vue-router"

const auth = getAuth();
const router = useRouter();

const logout = () => {
  signOut(auth);
  router.push('/login');
}
</script>

<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <router-link class="navbar-brand" to="/">Vite-Project</router-link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <div class="d-flex">
        <button class="btn btn-outline-primary" @click="logout">logout</button>
      </div>
    </div>
  </div>
</nav>
</template>